use std::io;
fn main() {
    println!("Code          Item            Price");
    println!(" L            Laptop          550,000");
    println!(" M            Monitor         120,000");
    println!(" K            Keyboard        15,000");
    println!(" H            Headset         25,000");

    let l_cost:f32=550_000.0;
    let m_cost:f32=120_000.0;
    let k_cost:f32=15_000.0;
    let h_cost:f32=25_000.0;
  

    println!("Enter an item code ");
    let mut input1 = String::new();
    io::stdin().read_line(&mut input1).expect("Not a valid string");
    let item_code:char = input1.trim().parse().expect("Not a valid number");

    println!("Enter the Quantity: ");
    let mut input2= String::new();
    io::stdin().read_line(&mut input2).expect("Not a valid string");
    let q:f32 = input2.trim().parse().expect("Not a valid number");


    if item_code == l
    {
        let total:f32= l_cost*q;
        println!("The total cost is {}" total);
    }else if item_code == m
    {
        let total:f32= m_cost*q;
        println!("The total cost is {}",total);

    }else if item_code== k
    {
        let total:f32= k_cost*q;
        println!("The total cost is {}",total );
    }else if item_code==h{
        let total:f32= h_cost*q;
        println!("The total cost is {}",total );
    }

}
