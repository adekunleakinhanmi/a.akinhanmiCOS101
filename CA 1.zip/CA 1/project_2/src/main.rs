use std::io;
fn main() {
    

        let mut input1= String::new();
    let mut input2 = String::new();
    let mut input3 = String::new();

        println!("Enter the Principal: ");
    io::stdin().read_line(&mut input1).expect("Not a valid string");
    let p:f32 = input1.trim().parse().expect("Not a valid number");

    println!("Enter the Rate: ");
    io::stdin().read_line(&mut input2).expect("Not a valid string");
    let r:f32 = input2.trim().parse().expect("Not a valid number");

    println!("Enter the time in years: ");
    io::stdin().read_line(&mut input3).expect("Not a valid string");
    let t:f32 = input1.trim().parse().expect("Not a valid number");

    let a= (p*(1.0+r/100.0))*t;
    let ci= a-p;


         println!("The compound interest is {}",ci);
    println!("The Total Amount is {}",a);
    
    



}
